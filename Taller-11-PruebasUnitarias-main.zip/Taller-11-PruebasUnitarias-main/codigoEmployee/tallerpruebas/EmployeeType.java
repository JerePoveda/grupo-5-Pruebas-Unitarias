package tallerpruebas;

public enum EmployeeType { Worker, Supervisor, Manager }
